export VPU_FIRMWARE_FILE="vpu_nvr.bin"
modprobe hantrodriver
source /opt/intel/codec-nvr/codec-nvr.sh 
export LD_LIBRARY_PATH=/opt/openvino/opencv/lib:/opt/openvino/deployment_tools/inference_engine/lib/aarch64:/usr/lib/gstreamer-1.0:/usr/share/gst-video-analytics
export GST_PLUGIN_PATH=/usr/share/gst-video-analytics
export GST_DEBUG=2
export USE_SIPP=1
source /opt/openvino/bin/setupvars.sh
export SIPP_FIRST_SHAVE=3
export ENABLE_GVA_FEATURES=compact-meta
printf "1\n3\n" | XLinkStartStop
ulimit -n 65532
ulimit -c unlimited

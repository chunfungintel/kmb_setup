export VPU_FIRMWARE_FILE="vpu_nvr_b0.bin"
export LD_LIBRARY_PATH=/opt/opencv/lib:/opt/InferenceEngine/lib/aarch64:/usr/lib/gstreamer-1.0:/usr/lib/gst-video-analytics
export GST_PLUGIN_PATH=/usr/lib/gst-video-analytics
export GST_DEBUG=2
export USE_SIPP=1
source /opt/openvino/bin/setupvars.sh
export SIPP_FIRST_SHAVE=3
export ENABLE_GVA_FEATURES=compact-meta
sh /opt/intel/codec-unify/unify.sh
modprobe hantrodriver-unify
ulimit -n 65532
ulimit -c unlimited

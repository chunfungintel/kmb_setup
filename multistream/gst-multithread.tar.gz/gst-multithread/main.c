#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <getopt.h>
#include <string.h>
#include <unistd.h>
#include <gst/gst.h>


#define DEFAULT_LAUNCH_FILE_NAME "./launch.txt"
#define FILE_EXIST(file) (file && !access (file, F_OK))
#define confirm_file(file0, file1) \
    (FILE_EXIST(file0) ? file0 : (FILE_EXIST(file1) ? file1 : NULL))
#define MAX_THREADS 10

const char *g_launch_filename[MAX_THREADS] = {0};
int ThreadNum = 1;
int arg_index = 0;

gchar *read_file(const char *filename);
static inline GstElement *create_pipeline_from_file(const char *file);
static void print_usage(FILE *stream, const char *program_name, int exit_code);
gboolean parse_cmdline(int argc, char *argv[]);
void *create_thread(void *data);
static gboolean bus_call(GstBus *bus, GstMessage *msg, gpointer data);

int main(int argc, char *argv[])
{
    //parse arguments
    if (!parse_cmdline(argc, argv)) {
        return -1;
    }
    //create thread
    if (arg_index == 0) {
        g_print("No launch file input!!!\n");
        return -1;
    }
    if (arg_index != 1) {
        ThreadNum =  arg_index;
    }
    g_print("You need produce %d threads\n", ThreadNum);
    static GThread *a[MAX_THREADS];
    int* index = g_new0(int, ThreadNum);
    for (int i = 0; i < ThreadNum; i++) {
        if(arg_index == 1) {
            index[i] = 0 ;
        } else {
            index[i] = i ;
        }
        a[i] = g_thread_new("test", create_thread, &index[i]);
    }
    for (int i = 0; i < ThreadNum; i++) {
        g_thread_join(a[i]);
    }
    g_free(index);
    return 0;
}

gchar *
read_file(const char *filename)
{
    FILE *fp = NULL;
    if (!(fp = fopen(filename, "rt"))) {
        g_print("failed to open file: %s\n", filename);
        return NULL;
    }
    gchar *data = NULL;
    size_t data_size = 0;
    fseek(fp, 0, SEEK_END);
    data_size = ftell(fp);
    rewind(fp);
    data = g_new0(char, data_size + 1);
    if (data_size != fread(data, 1, data_size, fp)) {
        g_free(data);
        data = NULL;
    }
    fclose(fp);
    return data;
}

static inline GstElement *
create_pipeline_from_file(const char *file)
{
    gchar      *data = NULL;
    GError     *error = NULL;
    GstElement *pipeline = NULL;
    if (!(data = read_file(file))) {
        return NULL;
    }
    pipeline = gst_parse_launch(data, &error);
    g_free(data);
    if (error || !pipeline) {
        g_print("failed to build pipeline from: %s error message: %s\n", file,
                (error) ? error->message : NULL);
        return NULL;
    }
    return pipeline;
}


static void
print_usage(FILE *stream, const char *program_name, int exit_code)
{
    fprintf(stream, "Usage: %s -l launchFile [OPTION]...\n", program_name);
    fprintf(stream,
            " -n --specify number of threads will be created. n>=1 && <=10\n"
            " -l --specify name of the launch file, support multi -l option, but when -l option >=2, the -n option not used.\n"
            " -h --help Display this usage information.\n");
    exit(exit_code);
}

gboolean
parse_cmdline(int argc, char *argv[])
{
    const char *const brief = "hn:l:";
    const struct option details[] = {
        { "ThreadNum", 1, NULL, 'n'},
        { "launch", 1, NULL, 'l'},
        { "help", 0, NULL, 'h'},
        { NULL, 0, NULL, 0 }
    };
    int opt = 0;
    while (opt != -1) {
        opt = getopt_long(argc, argv, brief, details, NULL);
        switch (opt)    {
            case 'n': {
                ThreadNum = atoi(optarg);
                if (ThreadNum <= 0 || ThreadNum > 10) {
                    print_usage(stderr, argv[0], 1);
                }
                break;
            }
            case 'l':
                g_launch_filename[arg_index] = optarg;
                arg_index++;
                break;
            case 'h': /* -h or --help */
                print_usage(stdout, argv[0], 0);
                break;
            case '?': /* The user specified an invalid option. */
                print_usage(stderr, argv[0], 1);
                break;
            case -1: /* Done with options. */
                break;
            default: /* Something else: unexpected. */
                abort();
        }
    }
    for(int i=0; i< arg_index;i++){
        g_launch_filename[i] = confirm_file(g_launch_filename[i],
                DEFAULT_LAUNCH_FILE_NAME);
        if (g_launch_filename[i]) {
            g_print("Launch file is %s\n", g_launch_filename[i]);
        } else {
            g_print("Can not find launch file\n");
            return FALSE;
        }
    }
    return TRUE;
}

void *create_thread(void *data)
{
    int index = *((int*)data);
    static int threadNow = 0;
    GMainLoop *loop = NULL;
    GstElement *myPipeline = NULL;
    GstBus *bus;
    guint bus_watch_id;
    gst_init(0, NULL);
    myPipeline = gst_pipeline_new("myPipeline");
    myPipeline = create_pipeline_from_file(g_launch_filename[index]);
    loop = g_main_loop_new(NULL, FALSE);
    if (!myPipeline) {
        g_print("failed to create pipeline from %s\n", g_launch_filename[index]);
        return NULL;
    }
    //Add a message handler
    bus = gst_pipeline_get_bus (GST_PIPELINE (myPipeline));
    bus_watch_id = gst_bus_add_watch (bus, bus_call, loop);
    gst_object_unref (bus);

    g_print("Have created the %d thread now\n", threadNow++);
    gst_element_set_state(myPipeline, GST_STATE_PLAYING);
    g_main_loop_run(loop);
    gst_element_set_state(myPipeline, GST_STATE_NULL);
    gst_object_unref(GST_OBJECT(myPipeline));
    g_source_remove (bus_watch_id);
    g_main_loop_unref(loop);
    return NULL;
}
static gboolean bus_call(GstBus *bus, GstMessage *msg, gpointer data)
{
    GMainLoop *loop = (GMainLoop *) data;
    switch (GST_MESSAGE_TYPE(msg)) {
        case GST_MESSAGE_EOS:
            g_print("End of stream\n");
            g_main_loop_quit(loop);
            break;
        case GST_MESSAGE_ERROR: {
            gchar *debug;
            GError *error;
            gst_message_parse_error(msg, &error, &debug);
            g_free(debug);
            g_printerr("Error: %s\n", error->message);
            g_error_free(error);
            g_main_loop_quit(loop);
            break;
        }
        default:
            break;
    }
    return TRUE;
}
